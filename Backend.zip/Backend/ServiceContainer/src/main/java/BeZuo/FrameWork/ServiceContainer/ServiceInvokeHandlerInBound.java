package BeZuo.FrameWork.ServiceContainer;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

import BeZuo.Common.ServiceAgent;
import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceInvokeResult;
import BeZuo.Common.ServiceResponseProtocolObject;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandler;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelPipeline;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.multipart.Attribute;
import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
import io.netty.handler.codec.http.multipart.InterfaceHttpData;
import io.netty.handler.codec.http.multipart.InterfaceHttpData.HttpDataType;


public class ServiceInvokeHandlerInBound extends ChannelInboundHandlerAdapter
{
	private ServiceAgent serviceAgent;
	//ĳ��ȷ����FD��channelRead����һֱ����ȷ����ͬһ���߳������У�����ʹ��ͬһ��buffer������Ҫ�����߳����⡣
	private byte[]	redBuffer;
		
	public void SetServiceAgent( ServiceAgent serviceAgent )
	{
		this.serviceAgent	= serviceAgent;
	}
	public ServiceInvokeHandlerInBound( ServiceAgent serviceAgent )
	{
		//��Ҫ��������֧�֣������Ż�
		redBuffer	= new byte[ 16 * 1024 ];
		this.serviceAgent	= serviceAgent;
	}
	@Override
    public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
        System.out.println( "-----ServiceContainer   channelRegistered" );
		ctx.fireChannelRegistered();
    }

    @Override
    public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
    	
    	System.out.println( "-----ServiceContainer   channelUnRegistered" );
        ctx.fireChannelUnregistered();
    }

	@Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
		System.out.println("-----ServiceContainer   Server channelActive");
        ctx.fireChannelActive();
    }
	 @Override
	 public void channelInactive(ChannelHandlerContext ctx) throws Exception 
	 {
		 System.out.println("-----ServiceContainer  Server channelInactive");
	     ctx.fireChannelInactive();
	 }
	 @Override
	 public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
	            throws Exception {
		 System.out.println("-----ServiceContainer  Server exceptionCaught");
		ctx.fireChannelInactive();
	 }
	 @Override
	 public void channelRead( ChannelHandlerContext ctx, Object msg ) throws Exception {
		 if( msg instanceof  FullHttpRequest )
	     {
			 ServiceContextInfo serviceContext	= new ServiceContextInfo();
			 FullHttpRequest req	= (FullHttpRequest) msg;
	    	 String uri			= req.getUri();
	    	 String[] array		= uri.split("/");
	    	 int seqNum			= 0;
	    	 //System.out.println( uri );
	    	 for( Map.Entry<String, String> entry : req.headers().entries() )
	    	 {
	    		 String key		= entry.getKey();
	    		 String value	= entry.getValue();
	    		 
	    		 if( key.equals( "SeqNum" ) )
	    		 {
	    			 seqNum	= Integer.valueOf( value );
	    		 }
	    		 else
	    		 {
	    			 serviceContext.AddContextInfo( key, value );
	    		 }
	    	 }
	    	 //uri �ִ���ʽΪ��/serviceName/funcName,�����һ��Ϊ��
	    	 if( array.length >=3 )
	    	 {
	    		String serviceName			= array[1];
	    		String funcNameAndData		= array[2];

	    		String[] queryStrings		= funcNameAndData.split( "[?]");	    		
	    		String funcName				= queryStrings[0];
	    		
	    		if( queryStrings.length == 2 )
	    		{
	    			String[] queryItems	= queryStrings[1].split( "&" );
	    			for( String queryItem : queryItems )
	    			{
	    				String[] item	= queryItem.split("=");
	    				if( 2 == item.length )
	    				{
	    					serviceContext.AddContextInfo( item[0], item[1] );
	    				}
	    			}
	    		}
	    				
	    		byte[] param		= null;
	    		//modifyed steven
	    		if( req.getMethod().equals( HttpMethod.POST ) )
	    		{
	    			ByteBuf buf	= req.content();	    
	    			int readableBytes	= buf.readableBytes();
	    			param		= new byte[readableBytes];
	    			buf.getBytes( 0 , param );	
	    		}	    		
	    		else if( req.getMethod().equals( HttpMethod.GET ) )
	    		{
	    			ByteBuf buf	= req.content();	    
	    			int readableBytes	= buf.readableBytes();
	    			param		= new byte[readableBytes];
	    			buf.getBytes( 0 , param );
	    		}
	    		/*
	    		 * ִ��ҵ�����
	    		 * 
	    		 * */
	    		
	    		ServiceInvokeResult result	= (ServiceInvokeResult) serviceAgent.InvokeService( serviceName, funcName , serviceContext, param );
	    		if( null != result )
	    		{
	    			ServiceResponseProtocolObject resp	= new ServiceResponseProtocolObject( result , seqNum ); 
	    			ctx.pipeline().write( resp );
	    		}
	    		
	    		/*
	    		 * 
	    		 * */
	    		
	    	 }
	     }
	 
	 }
}
