package BeZuo.FrameWork.ServiceContainer;

import java.lang.reflect.Method;
import java.util.Map;

import BeZuo.Common.ServiceHolder;
import BeZuo.ServiceModel.Test.UserInfoService;

public class SimpleServiceHolder extends ServiceHolder
{
	private Map<String , String > serviceClassNameMap;
	private Map<String , Object > serviceObjNameMap;
	private Map<String , Method > serviceMethodNameMap;
	private Map<String , Class > serviceClassMap;
	
	public void init()
	{
		
	}
	
	@Override
	public	Object GetServiceObject(String serviceName, String funcName) {
		// TODO Auto-generated method stub
		Object obj	= serviceObjNameMap.get( serviceName );
		if( null != obj )
		{
			return obj;
		}
		else
		{
			Class clazz	= GetServiceClass( serviceName , funcName );
			if( null != clazz )
			{
				try 
				{
					obj	= clazz.newInstance();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					obj	= null;
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					obj	= null;
					e.printStackTrace();
				}
				if( null != obj	)
				{
					serviceObjNameMap.put( serviceName , obj );
					return obj;
				}
			}
		}
		return null;
	}
	private	Class GetServiceClass(String serviceName, String funcName) 
	{
		Class clazz	= serviceClassMap.get( serviceName );
		if( null != clazz )
			return clazz;
		
		String serviceClassName	= serviceClassNameMap.get( serviceName );
		if( null != serviceClassName )
		{			
			try 
			{
				clazz	= Class.forName( serviceClassName );
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				clazz		= null;
				e.printStackTrace();
			}
			if( null != clazz )
			{
				serviceClassMap.put( serviceName, clazz );
				return clazz;
			}
		}
		return null;
	}
	@Override
	public 	Method GetServiceMethod(String ServiceName, String funcName) 
	{
		// TODO Auto-generated method stub
		StringBuffer buffer	= new StringBuffer( ServiceName );
		buffer.append( "." );
		buffer.append( funcName );
		Method method	= serviceMethodNameMap.get( buffer.toString() );
		if( null == method )
		{
			Class clazz	= GetServiceClass( ServiceName , funcName );
			if( null != clazz )
			{
				try 
				{						
					method	= clazz.getMethod( funcName );
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					method	= null;
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					method	= null;
					e.printStackTrace();
				}
				if( null != method )
				{
					serviceMethodNameMap.put( buffer.toString() , method );
					return method;
				}
			}
			return null;
		}
		return method;
	}

}
