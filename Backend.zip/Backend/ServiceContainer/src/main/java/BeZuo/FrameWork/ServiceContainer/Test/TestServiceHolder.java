package BeZuo.FrameWork.ServiceContainer.Test;

import java.lang.reflect.Method;

import BeZuo.Common.ServiceContextInfo;
import BeZuo.FrameWork.ServiceClient.IServiceBus;
import BeZuo.FrameWork.ServiceContainer.ServiceContainer;
import BeZuo.ServiceModel.ImageModal.ImageService;
import BeZuo.ServiceModel.Test.MainPageService;
import BeZuo.ServiceModel.Test.UserInfoService;

public class TestServiceHolder extends BeZuo.Common.ServiceHolder
{
	private UserInfoService userInfo;
	private MainPageService page;
	private ImageService imageService;
	private IServiceBus	serviceBus;
	
	public void setServiceBus( IServiceBus serviceBus )
	{
		this.serviceBus = serviceBus;
	}
	public void  init()
	{
		//super( container );
		userInfo	= new UserInfoService(   );
		//userInfo.SetServiceBus( container.GetServiceBus() );
		page		= new MainPageService(  );
		//page.SetServiceBus( container.GetServiceBus() );
		//imageService	= new ImageService( );
	}
	public Object GetServiceObject( String serviceName , String funcName )
	{
		//System.out.println("TestServiceHolder.GetServiceObject");
		if( serviceName.equals( "UserInfoService" ) )
			return userInfo;
		else if( serviceName.equals( "MainPageService" ) )
			return page;
		else if( serviceName.equals( "ImageService" ) )
		{
			return imageService;
		}
		return null;
	}
	private Method getServiceMethod( String serviceName , String funcName , Class paramType )
	{
		Method method	= null;
		if( funcName.equals("GetUserName" ) )
		{
			try {
				method	=  UserInfoService.class.getMethod( "GetUserName" , paramType , ServiceContextInfo.class );
			} catch (NoSuchMethodException e ) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch ( SecurityException e )
			{
				e.printStackTrace();
			}
		}
		else if( funcName .equals( "GetMainPageInfo"  ) )
		{
			try {
				method	= MainPageService.class.getMethod( "GetMainPageInfo" , paramType , ServiceContextInfo.class  );
			} catch (NoSuchMethodException e ) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch ( SecurityException e)
			{
				e.printStackTrace();
			}
		}
		else if( funcName .equals( "GetImage"  ) )
		{
			try {
				method	= ImageService.class.getMethod( "GetImage" , paramType, ServiceContextInfo.class  );
			} catch (NoSuchMethodException e ) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch ( SecurityException e)
			{
				e.printStackTrace();
			}
		}
		
		return method;
	}
	public Method GetServiceMethod( String serviceName , String funcName )
	{
		Method method	= null;
		method	= getServiceMethod( serviceName , funcName , byte[].class );
		if( null != method ) 
			return method;
		return null;
	}
}
