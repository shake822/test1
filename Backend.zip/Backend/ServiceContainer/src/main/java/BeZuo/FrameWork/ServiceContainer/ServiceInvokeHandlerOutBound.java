package BeZuo.FrameWork.ServiceContainer;

import java.util.Map;

import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceResponseProtocolObject;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;

public class ServiceInvokeHandlerOutBound extends ChannelOutboundHandlerAdapter
{
	 public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception 
	 {
		ServiceResponseProtocolObject resp	= (ServiceResponseProtocolObject) msg;
		HttpResponseStatus responseStatus	= HttpResponseStatus.valueOf( resp.GetResult().GetResponseStatus().code() );
		DefaultFullHttpResponse httpResp	= new DefaultFullHttpResponse( HttpVersion.HTTP_1_1 , responseStatus );
		int contentLen	= 0;
		
		Object resultDataObj	= resp.GetResult().GetResultData();
		if( null != resultDataObj )
		{
			byte[] result	= (byte[]) ( resultDataObj );
			contentLen	= result.length;
			httpResp.content().writeBytes( result , 0, contentLen );
		}
		
		ServiceContextInfo resultContext	= resp.GetResult().GetResultContext();
		if( null != resultContext )
		{
			Map<String,String> contextValues	= resultContext.GetInvokeServiceContextInfo();
			for(  Map.Entry< String , String > entry :  contextValues.entrySet() )
			{
				String key		= entry.getKey();
				String value	= entry.getValue();
				if( ! ( key.equals( "SeqNum" ) || key.equals( "Content-Length" ) ) )
				{
					httpResp.headers().add( key, value );
				}
			}
		}
		
		httpResp.headers().add( "SeqNum", resp.GetSeqNum() );
		httpResp.headers().add( "Content-Length"  , String.valueOf(  contentLen ) );		
		ctx.write( httpResp, promise );	 	
		ctx.flush();
	 }
}
