package BeZuo.FrameWork.ServiceContainer;

import BeZuo.Common.LocalServiceContext;
import BeZuo.Common.ServiceAgent;
import BeZuo.Common.ServiceEndPoint;
import BeZuo.Common.ServiceHolder;
import BeZuo.FrameWork.ServiceClient.IServiceBus;
import BeZuo.FrameWork.ServiceClient.ServiceClientBootstrap;
import BeZuo.FrameWork.ServiceContainer.Test.TestServiceHolder;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

public class ServiceContainer 
{
	private EventLoopGroup bossGroup;
	private EventLoopGroup workGroup;
	private ServerBootstrap serverBootStrap;
	private ChannelFuture channelFutrue;
	private ServiceAgent serviceAgent;
	private ServiceEndPoint localServiveEndpoint;
	
	public ServiceContainer ( EventLoopGroup bossGroup , EventLoopGroup workGroup ,LocalServiceContext localServiceContext, ServiceAgent serviceAgent /*, String bindIP, int port*/)
	{
		this.bossGroup	= bossGroup;
		this.workGroup	= workGroup;
		channelFutrue	= null;
		this.localServiveEndpoint	= localServiceContext.GetLocalServiceEndPoint();
		this.serviceAgent	= serviceAgent;
	}
	public ServiceEndPoint GetLocalEndPoint()
	{
		return localServiveEndpoint;
	}
	
	public void init()
	{		
		serverBootStrap = new ServerBootstrap();
		serverBootStrap.group( bossGroup, workGroup )
        .channel( NioServerSocketChannel.class )
        .option( ChannelOption.SO_BACKLOG, 100 )
        .handler( new LoggingHandler(LogLevel.INFO ) )
        .childHandler( new ChannelInitializer<SocketChannel>() 
        {
        	//һ��Ҫע�⣬���Ƕ��߳�����
             @Override
             public void initChannel(SocketChannel ch) throws Exception 
             {
            	 ChannelPipeline serverPipeline = ch.pipeline();
            	 serverPipeline.addLast("http",new HttpServerCodec( ) );
            	 serverPipeline.addLast("httpAgg",new HttpObjectAggregator( 8192 ));
            	 serverPipeline.addLast("ServiceInvokeHandlerInBound",new ServiceInvokeHandlerInBound( serviceAgent ) );
            	 serverPipeline.addLast("ServiceInvokeHandlerOutBound",new ServiceInvokeHandlerOutBound() );
             }
        });
	}
    public int BeginService() 
    {
    	try 
    	{
    		//System.out.println( "Server bind" ) ;
    		channelFutrue = serverBootStrap.bind( localServiveEndpoint.GetIP() , localServiveEndpoint.GetPort() ).sync();
		
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
    	return 0;
    }
    public void WaitForClose()
    {
    	try 
    	{
			channelFutrue.channel().closeFuture().sync();
		} 
    	catch (InterruptedException e) 
    	{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
