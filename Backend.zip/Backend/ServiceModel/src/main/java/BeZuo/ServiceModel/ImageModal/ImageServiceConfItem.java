package BeZuo.ServiceModel.ImageModal;

import BeZuo.Common.ConfItem;
import BeZuo.Common.IConfiguration;

public class ImageServiceConfItem extends ConfItem
{
	int cacheItemSize;
	String baseLocation;
	public ImageServiceConfItem()
	{
		cacheItemSize	= 0;
		baseLocation	= "";
	}
	public int GetCacheItemSize()
	{
		return this.cacheItemSize;
	}
	public String GetLocalFileSystemBaseLocation()
	{
		return this.baseLocation;
	}
	public void InitWithConfigure( IConfiguration conf )
	{		
		String cacheItemSizeStr	= conf.GetStringConf( "ImageService\\CacheItemSize" );
		if( null != cacheItemSizeStr &&( ! cacheItemSizeStr.isEmpty() ) )
		{
			try
			{
				cacheItemSize	= Integer.valueOf( cacheItemSizeStr );
				if( 0 == cacheItemSize )
				{
					cacheItemSize	=  128 * 1024;
				}
			}catch( NumberFormatException e)
			{
				cacheItemSize	= 128 * 1024;
			}
		}
		else
		{
			cacheItemSize	=  128 * 1024;
		}
		
		baseLocation			= conf.GetStringConf( "ImageService\\BaseLocation" );
		if( null == baseLocation )
		{
			baseLocation = "";
		}
	}
	public boolean equals( ConfItem conf )
	{
		if( cacheItemSize == ( ( ImageServiceConfItem )conf ).GetCacheItemSize() && baseLocation.equals( ( ( ImageServiceConfItem )conf ).GetLocalFileSystemBaseLocation() ) )
			return true;
		return false;
	}
}
