package BeZuo.ServiceModel.Storage;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.imageio.ImageIO;

import BeZuo.Common.ConfItem;
import BeZuo.Common.IConfigurableObject;
import BeZuo.Common.IConfiguration;
import BeZuo.ServiceModel.ImageModal.ImageServiceConfItem;
import net.coobird.thumbnailator.Thumbnails;

public class LocalFileSystemStorage implements IFileStorage, IConfigurableObject
{
	private IConfiguration conf;
	private String baseLocation;
	private ImageServiceConfItem confItem;
	private Lock lockForUpdate;
	public LocalFileSystemStorage( IConfiguration conf )
	{
		this.conf		= conf;
		confItem		= new ImageServiceConfItem();
		confItem.InitWithConfigure( conf );
		baseLocation	= confItem.GetLocalFileSystemBaseLocation();
		lockForUpdate	= new ReentrantLock();
	}

	public void UpdateConfig( ConfItem conf ) 
	{
		lockForUpdate.lock();
		baseLocation	= confItem.GetLocalFileSystemBaseLocation();
		lockForUpdate.unlock();
		// TODO Auto-generated method stub	
	}
	public byte[] GetFileDatas( URI uri, /*out����*/Map<String, String> context ) 
	{
		// TODO Auto-generated method stub
		String fileName	= uri.getPath();
		if( null != fileName && ( ! fileName.isEmpty() ) )
		{
			lockForUpdate.lock();
			String metaDataFileLocation	= baseLocation + fileName + ".meta";
			String dataFileLocation		= baseLocation + fileName;
			lockForUpdate.unlock();
			//ByteArrayOutputStream outStream	= new ByteArrayOutputStream();		
			File file	= new File( dataFileLocation );
			
			byte[] buffer	= null;
			try 
			{	
				DataInputStream metaStream	= new DataInputStream( new FileInputStream( metaDataFileLocation ) );
				int width	= metaStream.readInt();
				int height	= metaStream.readInt();
				InputStream stream	= new FileInputStream( file );
				context.put( "ImageWidth" , String.valueOf( width ) );
				context.put( "ImageHeight" , String.valueOf( height ) );
				
				buffer	= new byte[ (int) file.length() ];
				stream.read( buffer );
			}	
			catch( Exception e)
			{				
				buffer	= null;
			}
			return buffer;
		}
		return null;
	}

	public URI UploadFile(String fileName, byte[] datas, Map<String, String> context) {
		// TODO Auto-generated method stub
		int imageWidth			= 0;
		int imageHeight			= 0;
		if( null != context )
		{
			
			String imageWidthStr	= context.get( "ImageWidth" );
			String imageHeightStr	= context.get( "ImageHeight" );
			
			if( ( imageWidthStr != null && (! imageWidthStr.isEmpty() ) ) &&( imageHeightStr != null && (! imageHeightStr.isEmpty() )) )
			{
				try
				{
					imageWidth	= Integer.valueOf( imageWidthStr );
					imageHeight	= Integer.valueOf( imageHeightStr );
				}
				catch( NumberFormatException e)
				{
					
				}
			}
		}
		if( 0 == imageWidth || 0 == imageHeight )
		{
			boolean fileReadError	= false;
			BufferedImage sourceImg	= null;
			try {
				sourceImg = ImageIO.read( new ByteArrayInputStream( datas ) );
			} catch (IOException e) {
				// TODO Auto-generated catch block
				fileReadError	= true;
				e.printStackTrace();
			}   
			if( ! fileReadError && null != sourceImg )
			{
				imageWidth	= sourceImg.getWidth();  
				imageHeight	= sourceImg.getHeight();  				
			}
		}
		lockForUpdate.lock();
		String metaDataFileLocation	= baseLocation + fileName + ".meta";
		String dataFileLocation		= baseLocation + fileName;
		lockForUpdate.unlock();
		boolean dataFileReadError	= false;
		try {
			FileOutputStream outputData	= new FileOutputStream( dataFileLocation );
			outputData.write( datas );	
			outputData.close();
			DataOutputStream outputMeta	= new DataOutputStream(  new FileOutputStream( metaDataFileLocation ) );
			outputMeta.writeInt( imageWidth );	
			outputMeta.writeInt( imageHeight );	
			outputMeta.close();
		} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
			dataFileReadError	= true;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			dataFileReadError	= true;
			e.printStackTrace();
		}
		if( ! dataFileReadError )
			return URI.create( fileName );
		else
			return null;
	}
	public Map<String, String> GetFileMetaData(URI uri) {
		// TODO Auto-generated method stub
		String fileName	= uri.getPath();
		String metaDataFileLocation	= baseLocation + fileName + ".meta";
		DataInputStream metaStream;
		boolean error	= false;
		int width		= 0;
		int height		= 0;
		try {
			metaStream = new DataInputStream( new FileInputStream( metaDataFileLocation ) );
			width	= metaStream.readInt();
			height	= metaStream.readInt();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			error		= true;
			e.printStackTrace();
		}	
		catch ( IOException e)
		{
			error		= true;
			e.printStackTrace();
		}
		if( !error )
		{
			Map<String,String> result	= new TreeMap<String,String>();
			result.put( "ImageWidth" , String.valueOf( width ) );
			result.put( "ImageHeight" , String.valueOf( height ) );
			return result;
		}
		return null;
	}

	public boolean DeleteFile(URI uri) {
		// TODO Auto-generated method stub
		String fileName	= uri.getPath();
		if( null != fileName && ( ! fileName.isEmpty() ) )
		{
			String metaDataFileLocation	= baseLocation + fileName + ".meta";
			String dataFileLocation		= baseLocation + fileName;
			File fMeta = new File( metaDataFileLocation ); // ����Ҫɾ�����ļ�λ��
			if( fMeta .exists())
				fMeta.delete(); 
			File fdata = new File( dataFileLocation ); // ����Ҫɾ�����ļ�λ��
			if( fdata.exists())
				fdata.delete(); 
		}
		return true;
	}
	

}
