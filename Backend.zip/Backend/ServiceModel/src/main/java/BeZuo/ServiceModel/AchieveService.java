package BeZuo.ServiceModel;

public class AchieveService 
{
	Object GetTopAchieve( Object param )
	{
		return param;
		
	}
	Object GetAchieveCount( Object param )
	{
		return param;
		
	}
	Object GetAchieveFromTo( Object param )
	{
		return param;
		
	}
}
