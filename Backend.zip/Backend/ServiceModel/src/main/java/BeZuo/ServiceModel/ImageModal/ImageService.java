package BeZuo.ServiceModel.ImageModal;

import io.netty.handler.codec.bytes.ByteArrayDecoder;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.Map;
import java.util.TreeMap;

import net.coobird.thumbnailator.Thumbnails;
import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceInvokeResult;
import BeZuo.Common.ServiceResponseStatus;
import BeZuo.FrameWork.ServiceClient.IServiceBus;
import BeZuo.ServiceModel.BusiModalBase;
import BeZuo.ServiceModel.Storage.IFileStorage;
import BeZuo.ServiceModel.Storage.IFileStorageClient;

public class ImageService  extends BusiModalBase
{
	private ImageLRUCache imageCache;
	
	public ImageService( ImageLRUCache imageCache )
	{
		// TODO Auto-generated constructor stub
		this.imageCache	= imageCache;
	}
	
	public ServiceInvokeResult GetImage( byte[] data , ServiceContextInfo serviceContext )
	{
		ImageServiceQueryParam queryParam	= new ImageServiceQueryParam( this.conf );
		queryParam.parse( data , serviceContext );
		if( null != queryParam.GetImageUriStr() )
		{		
			byte[] imageData	= imageCache.GetImageData( queryParam.GetImageUriStr() , queryParam.GetScaleWidth(), queryParam.GetScaleHeight() );
			if( null != imageData )
			{
				ServiceContextInfo contextInfo	= new ServiceContextInfo();
				//ͨ���ļ���׺��ȷ��mimetype
				if( queryParam.GetImageUriStr().endsWith( "jpg" ) )
					contextInfo.AddContextInfo( "Content-Type", "image/jpeg" );
				else if( queryParam.GetImageUriStr().endsWith( "png" ) )
					contextInfo.AddContextInfo( "Content-Type", "image/png" );
				return new ServiceInvokeResult( ServiceResponseStatus.OK,  imageData , contextInfo );
			}
			else
			{
				return new ServiceInvokeResult( ServiceResponseStatus.PROMPT_ERROR,  "file not existed or scale is illegal".getBytes() , null );
			}
		}
		else
		{
			return new ServiceInvokeResult( ServiceResponseStatus.PROMPT_ERROR , "parameter imageName not find".getBytes() , null );
		}
	}
	public ServiceInvokeResult UploadImage( byte[] data , ServiceContextInfo serviceContext )
	{
		Map<String,String> context	= serviceContext.GetInvokeServiceContextInfo();
		String imageName			= context.get( "imageName" );
		String imageWidthStr		= context.get( "ImageWidth" );
		String imageHeightStr		= context.get( "ImageHeight" );
		//��Ҫ�ϴ���ͼƬ����
		Map<String,String> uploadContext	= new TreeMap<String, String>();
		
		if( ( imageWidthStr != null && (! imageWidthStr.isEmpty() ) ) &&( imageHeightStr != null && (! imageHeightStr.isEmpty() )) )
		{
			try
			{
				Integer.valueOf( imageWidthStr );
				Integer.valueOf( imageHeightStr );
				uploadContext.put( "ImageWidth", imageWidthStr );
				uploadContext.put( "ImageHeight", imageHeightStr );
			}
			catch( NumberFormatException e)
			{
			}
		}
		
		if( null != imageName && ( !imageName.isEmpty() ) )
		{
			String fileName	= imageCache.UploadImageFile( imageName , data, uploadContext );
			if( null != fileName )
			{
				return new ServiceInvokeResult( ServiceResponseStatus.OK, fileName.getBytes() , null );
			}			
			else
			{
				return new ServiceInvokeResult( ServiceResponseStatus.INTERNAL_ERROR, "upload file failed".getBytes() , null );
			}
		}
		else
		{
			return new ServiceInvokeResult( ServiceResponseStatus.PROMPT_ERROR , "parameter imageName not find".getBytes() , null  );
		}
	}
	
}
