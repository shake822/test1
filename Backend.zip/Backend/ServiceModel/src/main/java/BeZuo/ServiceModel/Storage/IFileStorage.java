package BeZuo.ServiceModel.Storage;

import java.io.InputStream;
import java.net.URI;
import java.util.List;
import java.util.Map;

public interface IFileStorage extends IFileStorageClient
{
	URI UploadFile( String fileName , byte[] datas , Map<String,String> context );
	boolean DeleteFile( URI uri );
}
