package BeZuo.ServiceModel.ImageModal;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import BeZuo.Common.ConfItem;
import BeZuo.Common.IConfigurableObject;
import BeZuo.Common.IConfiguration;
import BeZuo.ServiceModel.Storage.IFileStorage;

public class ImageLRUCache extends LinkedHashMap< String,byte[]> implements IConfigurableObject
{
	private ImageStorage imageStorage;
	private int cacheItemSize;
	//private IConfiguration conf;
	private int capacity;
	private Lock lockForLruMap;
	private ImageServiceConfItem confItem;
	private final static String SEPERATOR	= "|";
	public void UpdateConfig( ConfItem confItem ) {
		// TODO Auto-generated method stub
		cacheItemSize	= ( (ImageServiceConfItem) confItem ).GetCacheItemSize();
	}
	private URI getURIFromFileName( String fileName )
	{
		String[] parts	= fileName.split( "[|]" );
		if( 2 == parts.length )
		{
			String schema	= "fastdfs";
			String fragment	= parts[0];
			String path		= parts[1];
			path			= path.replace( '-' , '/' );
			URI uri			= null;
			try {
				uri = new URI( schema , null, path, fragment );
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return uri;
		}
		return null;		
	}
	String getImageFileNameFromURI( URI uri )
	{
		String filePath	= uri.getPath();
		filePath	= filePath.replace( '/' , '-' );
		StringBuffer buffer	= new StringBuffer( uri.getFragment() );
		buffer.append( SEPERATOR ).append( filePath );
		return buffer.toString();
	}
	public ImageLRUCache( IConfiguration conf , ImageStorage imageStorage , int capacity )
	{
		super( capacity );
		confItem			= new ImageServiceConfItem();
		confItem.InitWithConfigure( conf );
		lockForLruMap		= new ReentrantLock();
		this.capacity		= capacity;
		this.imageStorage	= imageStorage;
		cacheItemSize		= confItem.GetCacheItemSize();
	}
	protected boolean removeEldestEntry(Map.Entry<String , byte[]> eldest) 
	{
		if( size() > this.capacity )
		{  
			return true;  
        }  
        return false; 
	}
	public byte[] GetImageData( String fileName , int scaleWidth, int scaleHeight )
	{
		byte[] data	= null;
		if( null != fileName && ( ! fileName.isEmpty() ) )
		{
			StringBuffer keyStr	= new StringBuffer( fileName );
			keyStr.append(scaleWidth).append( scaleHeight );
			String key	= keyStr.toString();
			lockForLruMap.lock();
			data = (byte[]) get( key );
			lockForLruMap.unlock();
			if( null == data )
			{
				Map<String,String> contextData	= new TreeMap<String,String>();
				//���ļ�����ʽת��Ϊ�ļ��洢·��				
				data	= imageStorage.GetImageData( getURIFromFileName( fileName ), contextData );
				if( null != data )
				{
					String imageWidthStr	= contextData.get( "ImageWidth" );
					String imageHeightStr	= contextData.get( "ImageHeight" );
					int imageWidth	= Integer.valueOf( imageWidthStr );
					int imageHeight	= Integer.valueOf( imageHeightStr );
					//����ͼ�����ܱ�ԭͼ��Ҫ��
					if( scaleWidth > imageWidth || scaleHeight > imageHeight )
					{
						return null;
					}
					if( scaleWidth == 0 )
						scaleWidth	= imageWidth;
					if( 0 == scaleHeight )
						scaleHeight	= imageHeight;
					int selectedReginWidth	= 0;
					int selectedReginHeight	= 0;
					float ration1	= (float)imageWidth / imageHeight;
					float ration2	= (float)scaleWidth / scaleHeight;
					float choiceRatio	= 0.0f;
					//���ͼƬ����������ͼҪ��
					if( ration1 > ration2 )
					{
						choiceRatio		= (float)imageHeight / scaleHeight;
					}
					else
					{
						choiceRatio		= (float)imageWidth / scaleWidth;
					}
					selectedReginWidth	= (int) (choiceRatio * scaleWidth);
					selectedReginHeight	= (int) (choiceRatio * scaleHeight);
						
					//Thumbnails.of( stream ).size(400, 400).toOutputStream( outStream );
					ByteArrayOutputStream outStream	= new ByteArrayOutputStream();
					
					try {
						Thumbnails.of( new ByteArrayInputStream( data ) ).sourceRegion( Positions.CENTER,
								selectedReginWidth, selectedReginHeight).size(scaleWidth, scaleHeight).toOutputStream( outStream );
						
						data	= outStream.toByteArray();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					if( null != data )
					{
						int	size	= data.length ;
						if( data.length < cacheItemSize )
						{
							lockForLruMap.lock();
							put( key , data );
							lockForLruMap.unlock();
						}
					}
				}
			}
		}
		return data;
		
	}
	
	public String UploadImageFile( String fileName, byte[] datas ,Map<String,String> contextt ) 
	{
		URI location	= imageStorage.UploadImageFile( fileName , datas, contextt );
		return getImageFileNameFromURI(location) ;
	}
	
	
}
