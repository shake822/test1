package BeZuo.ServiceModel.Storage;

import java.net.URI;
import java.util.Map;

public interface IFileStorageClient 
{
	byte[] GetFileDatas( URI uri ,/*out*/ Map<String,String> context );
	Map<String,String> GetFileMetaData( URI uri  );
}
