package BeZuo.ServiceModel;

import BeZuo.Common.IConfiguration;
import BeZuo.FrameWork.ServiceClient.IServiceBus;

public class BusiModalBase 
{
	protected IServiceBus serviceBus;
	protected IConfiguration conf;
	public void setServiceBus( IServiceBus serviceBus ) 
	{
		this.serviceBus	= serviceBus;
	}
	public void setConfigure( IConfiguration conf ) 
	{
		this.conf	= conf;
	}
}
