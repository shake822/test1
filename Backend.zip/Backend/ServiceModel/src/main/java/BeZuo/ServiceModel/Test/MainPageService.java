package BeZuo.ServiceModel.Test;

import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceInvokeFuture;
import BeZuo.Common.ServiceInvokeResult;
import BeZuo.Common.ServiceResponseStatus;
import BeZuo.FrameWork.ServiceClient.IServiceBus;
import BeZuo.ServiceModel.BusiModalBase;

public class MainPageService extends BusiModalBase
{
	public MainPageService(   )
	{
	}
	public ServiceInvokeResult GetMainPageInfo(  byte[] data , ServiceContextInfo contextInfo )
	{
		System.out.println( "MainPageService::GetMainPageInfo");
		ServiceInvokeFuture<byte[]> result1	= serviceBus.<byte[]>InvokeService( "UserInfoService", "GetUserName", contextInfo , ("myid").getBytes() );
		ServiceInvokeFuture<byte[]> result2	= serviceBus.<byte[]>InvokeService( "UserInfoService", "GetUserName", contextInfo , ("myid").getBytes() );
		
		if( result1.isDone() && result2.isDone() )
		{
			byte[] byte1	= result1.get( 6 * 1000);
			byte[] byte2	= result2.get( 6 * 1000);
			String userName1	= new String( byte1 );	
			String userName2	= new String( byte2 );	
			//String userName1	= result1.get();	
			//String userName2	= result2.get( );	
					
			System.out.println( "invoke is ok-----------------------" );
			String pageid	= new String( data );
			if( result1.isDone() && null != userName1 )
			{
				return new ServiceInvokeResult( ServiceResponseStatus.OK , ("PAGEID"+pageid+",Username:"+userName1).getBytes() , null );	
			}
			else if( result1.isTimeout() )
			{
				return new ServiceInvokeResult( ServiceResponseStatus.PROMPT_ERROR , ("time out").getBytes() , null );
			}
		}
		return new ServiceInvokeResult( ServiceResponseStatus.INTERNAL_ERROR , ("some inner error").getBytes() , null );
				
	}
}
