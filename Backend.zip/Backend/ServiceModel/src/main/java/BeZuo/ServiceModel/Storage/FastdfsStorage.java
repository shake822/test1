package BeZuo.ServiceModel.Storage;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.TreeMap;

import javax.imageio.ImageIO;

import org.csource.common.MyException;
import org.csource.common.NameValuePair;
import org.csource.fastdfs.ClientGlobal;
import org.csource.fastdfs.StorageClient;
import org.csource.fastdfs.TrackerClient;
import org.csource.fastdfs.TrackerGroup;
import org.csource.fastdfs.TrackerServer;

import BeZuo.Common.IConfiguration;

public class FastdfsStorage implements IFileStorage
{
	private FastdfsStorageConfItem confItem;
	private ClientGlobal fdfsClient;
	private StorageClient storageClient;
	public FastdfsStorage( IConfiguration conf )
	{
		confItem	= new FastdfsStorageConfItem();
		confItem.InitWithConfigure( conf );
		InetSocketAddress[] address	= new InetSocketAddress[ confItem .GetFastdfsTrackerGroup().size() ];
		int count	= confItem .GetFastdfsTrackerGroup().size();
		for( int i = 0 ; i < count ; i++ )
		{
			address[i]	= new InetSocketAddress( confItem .GetFastdfsTrackerGroup().get( i ).GetIP() , confItem .GetFastdfsTrackerGroup().get( i ).GetPort()  );
		}
		TrackerGroup trackerGroup	= new TrackerGroup( address );
		fdfsClient.setG_tracker_group( trackerGroup );
		fdfsClient.setG_charset( confItem.GetFastdfsCharSet() );
		storageClient	= new StorageClient( );
	}
	private String[] GetGroupAndFileName( URI uri )
	{
		if( null == uri )
			return null;
		//String path		= uri.getPath();
		String[] result	= new String[2];
		result[0]		= uri.getFragment();
		//filename��Ҫȥ����һ��/		
		result[1]		= uri.getPath().substring( 1 );
		return result;
	}
	public boolean DeleteFile( URI uri )
	{
		String[] groupAndFileName	= GetGroupAndFileName( uri );
		boolean result	= true;
		if( null != groupAndFileName )
		{
			try {
				storageClient.delete_file( groupAndFileName[0] , groupAndFileName[1] );
			} catch (IOException e) {
				// TODO Auto-generated catch block
				result	= false;
				e.printStackTrace();
			} catch (MyException e) {
				// TODO Auto-generated catch block
				result	= false;
				e.printStackTrace();
			}
		}
		else
		{
			result	= false;
		}
		return result;
		
	}
	private URI CreateURIWithGroupAndFileName( String groupName , String filePath )
	{
		if( (! groupName.isEmpty() ) && ( ! filePath.isEmpty() ) )
		{					
			try {
				//URI��ʽ����
				StringBuffer buffer	= new StringBuffer("/");
				buffer.append( filePath );
				URI uri	= new URI( "fastdfs", null, buffer.toString(), groupName );
				return uri;
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	public byte[] GetFileDatas(URI uri, Map<String, String> context) {
		// TODO Auto-generated method stub
		String[] groupAndFileName	= GetGroupAndFileName( uri );
		byte[] result	= null;
		if( null != groupAndFileName )
		{
			Map<String,String> metaData	= GetFileMetaData( uri );
			context.putAll( metaData );
			try {
				result	= storageClient.download_file( groupAndFileName[0] , groupAndFileName[1] );
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return result;
	}

	public Map<String, String> GetFileMetaData(URI uri) {
		// TODO Auto-generated method stub
		String[] groupAndFileName	= GetGroupAndFileName( uri );
		Map<String,String> result	= new TreeMap<String,String>();
		if( null != groupAndFileName )
		{
			try {
				NameValuePair[] contextData	= storageClient.get_metadata( groupAndFileName[0], groupAndFileName[1] );
				if( null != contextData )
				{
					for( NameValuePair context : contextData )
					{
						result.put( context.getName() , context.getValue() );
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}

	public URI UploadFile(String fileName, byte[] datas,
			Map<String, String> context) {
		// TODO Auto-generated method stub
		//�ļ���չ��
		URI result			= null;
		//�з��ļ�������չ��
		String[] fileParts	= fileName.split( "[.]" );
		if( 2 != fileParts.length )
		{
			return null;
		}
		if( ( fileParts[0].isEmpty() || fileParts[1].isEmpty() ) )
		{
			return null;
		}
		String fileExtendName	= fileParts[1];
		NameValuePair[] pairs	= null;
		if( null != context )
		{
			pairs	= new NameValuePair[ context.size() ];
			int index	= 0;
			for( Map.Entry<String, String> entry : context.entrySet() )
			{
				pairs[ index ]		= new NameValuePair( entry.getKey() , entry.getValue() );
				index++;
			}			
		}
		String[] uploadResult		= null;
		try {
			uploadResult	= storageClient.upload_file( datas ,fileExtendName , pairs  );			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if( null != uploadResult )
		{
			if( 2 == uploadResult.length )
			{
				String groupName		= uploadResult[0];
				String uploadFileName	= uploadResult[1];
				result	= CreateURIWithGroupAndFileName( groupName , uploadFileName );
			}
		}
		return result;
	}

}
