package BeZuo.ServiceModel.ImageModal;

import BeZuo.Common.IConfiguration;
import BeZuo.Common.ServiceContextInfo;

public class ImageServiceQueryParam 
{
	IConfiguration	conf;
	String imageUri;
	int scaleWidth;
	int scaleHeight;
	public ImageServiceQueryParam( IConfiguration conf )
	{
		this.conf	= conf;
	}
	public void parse(  byte[] data , ServiceContextInfo serviceContext )
	{
		String imageName	= serviceContext.GetInvokeServiceContextInfo().get( "imageName" );
		String scale		= serviceContext.GetInvokeServiceContextInfo().get( "scale" );
		String maxWidthStr	= conf.GetStringConf( "ImageService/MaxWidth" );
		String maxHeightStr	= conf.GetStringConf( "ImageService/MaxHeight" );
		int maxWidth		= 0;
		int maxHeight		= 0;
		if( null != maxWidthStr && ( ! maxWidthStr.isEmpty() ) )
		{
			try
			{	
				maxWidth		= Integer.valueOf( maxWidthStr );
			}
			catch( NumberFormatException e)
			{
			}
		}
		if( null != maxHeightStr && ( ! maxHeightStr.isEmpty() ) )
		{
			try
			{
				maxHeight		= Integer.valueOf( maxHeightStr );
			}
			catch( NumberFormatException e)
			{
			}
		}
		int width	= 0;
		int height	= 0;
		if( null != imageName && ( ! imageName.isEmpty() ) )
		{
			this.imageUri	= imageName;			
			if( null != scale && ( ! imageName.isEmpty() ))
			{
				String[] scaleItems	= scale.split( "[*]" );
				if( 2 == scaleItems.length )
				{
					try
					{
						width	= Integer.valueOf( scaleItems[0] );
						height	= Integer.valueOf( scaleItems[1] );
					}
					catch( NumberFormatException e)
					{
						//�û��Ĳ������Ϸ���
					}
				}
			}
		}
		
		if( 0 == maxWidth )
			maxWidth	= Integer.MAX_VALUE;
		if( 0 == maxHeight )
			maxHeight	= Integer.MAX_VALUE;
		
		if( height <= maxHeight )
		{
			scaleHeight	= height;
		}
		else
			scaleHeight	= maxHeight;
		
		if( width <= maxWidth )
		{
			scaleWidth	= width;
		}
		else
			scaleWidth	= maxWidth;
	}
	public String GetImageUriStr()
	{
		return imageUri;
	}
	public int GetScaleWidth()
	{
		return scaleWidth;
	}
	public int GetScaleHeight()
	{
		return scaleHeight;
	}
}
