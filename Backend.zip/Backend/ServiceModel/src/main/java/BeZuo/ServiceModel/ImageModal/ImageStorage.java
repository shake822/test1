package BeZuo.ServiceModel.ImageModal;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.Map;
import java.util.TreeMap;

import javax.imageio.ImageIO;

import BeZuo.ServiceModel.Storage.IFileStorage;

public class ImageStorage 
{
	private IFileStorage fileStorage;
	public ImageStorage ( IFileStorage fileStorage )
	{
		this.fileStorage	=  fileStorage;
	}
	public byte[] GetImageData( URI fileuri , Map<String,String> context )
	{
		byte[] data	= null;
		if( null != fileuri )
		{
			data	= fileStorage.GetFileDatas( fileuri , context );
		}
		return data;
		
	}
	public URI UploadImageFile(String fileName, byte[] datas ,Map<String,String> context ) 
	{
		// TODO Auto-generated method stub
		int imageWidth			= 0;
		int imageHeight			= 0;		
		if( null != context )
		{			
			String imageWidthStr	= context.get( "ImageWidth" );
			String imageHeightStr	= context.get( "ImageHeight" );
			if( ( imageWidthStr != null && (! imageWidthStr.isEmpty() ) ) &&( imageHeightStr != null && (! imageHeightStr.isEmpty() )) )
			{
				try
				{
					imageWidth	= Integer.valueOf( imageWidthStr );
					imageHeight	= Integer.valueOf( imageHeightStr );
				}
				catch( NumberFormatException e)
				{				
					context.remove( "ImageWidth" );
					context.remove( "ImageHeight" );
				}
			}
		}
		if( 0 == imageWidth || 0 == imageHeight )
		{
			boolean fileReadError	= false;
			BufferedImage sourceImg	= null;
			try {
				sourceImg = ImageIO.read( new ByteArrayInputStream( datas ) );
			} catch (IOException e) {
				// TODO Auto-generated catch block
				fileReadError	= true;
				e.printStackTrace();
			}   
			if( ! fileReadError && null != sourceImg )
			{
				imageWidth	= sourceImg.getWidth();  
				imageHeight	= sourceImg.getHeight(); 
				context.put( "ImageWidth" , String.valueOf(imageWidth) );
				context.put( "ImageHeight" , String.valueOf(imageHeight) );
			}
		}
		
		URI saveLocation	= fileStorage.UploadFile( fileName , datas , context );
		return saveLocation;
	}
}
