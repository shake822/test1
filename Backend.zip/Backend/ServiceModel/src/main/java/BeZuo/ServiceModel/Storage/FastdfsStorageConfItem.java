package BeZuo.ServiceModel.Storage;

import java.util.ArrayList;
import java.util.List;

import BeZuo.Common.ConfItem;
import BeZuo.Common.IConfiguration;
import BeZuo.Common.ServiceEndPoint;

public class FastdfsStorageConfItem extends ConfItem
{
	List<ServiceEndPoint> trackerGroup; 
	String charset;
	FastdfsStorageConfItem()
	{
		trackerGroup	= new ArrayList<ServiceEndPoint>();
	}
	public List<ServiceEndPoint> GetFastdfsTrackerGroup()
	{
		return trackerGroup;
	}
	public String GetFastdfsCharSet()
	{
		return charset;
	}
	@Override
	public boolean equals(ConfItem conf) 
	{
		// TODO Auto-generated method stub
		if( trackerGroup.size() != ( (FastdfsStorageConfItem) conf ).GetFastdfsTrackerGroup().size() )
		{
			return false;
		}
		int count	 = trackerGroup.size();
		for( int i = 0 ; i < count ; i++ )
		{
			if( ! trackerGroup.get( i ). equals( ( ( FastdfsStorageConfItem ) conf ).GetFastdfsTrackerGroup().get(i) ) )
				return false;
		}
		return true;
	}

	@Override
	public void InitWithConfigure(IConfiguration conf) {
		// TODO Auto-generated method stub
		List<String> result	= conf.GetListConf( "FdfsConf\\TrackerServerList" );		
		if( null != result )
		{
			for( String confItem : result )
			{
				String[] endpointInfo	= confItem.split(":");
				if( 2 == endpointInfo.length )
				{
					int port		= 0;
					try
					{
						port	= Integer.valueOf( endpointInfo[1] );
					}
					catch( NumberFormatException e)
					{
					}
					if( 0 != port )
					{
						trackerGroup.add( new ServiceEndPoint( endpointInfo[0] , port  ) ) ;
					}
					
				}
			}
		}
		
		charset	= conf.GetStringConf( "FdfsConf\\Charset" );	
	}

}
