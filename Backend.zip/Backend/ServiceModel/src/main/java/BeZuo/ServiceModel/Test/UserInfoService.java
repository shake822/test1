package BeZuo.ServiceModel.Test;

import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceInvokeResult;
import BeZuo.Common.ServiceResponseStatus;
import BeZuo.FrameWork.ServiceClient.IServiceBus;
import BeZuo.ServiceModel.BusiModalBase;

public class UserInfoService extends BusiModalBase
{
	public UserInfoService(  )
	{
	}
	public ServiceInvokeResult GetUserName( byte[] data , ServiceContextInfo contextInfo ) 
	{
		/*
		try {
			Thread.sleep( 1*1000 );
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		System.out.println( "UserInfoService::GetUserName");
		return new ServiceInvokeResult( ServiceResponseStatus.OK , (new String( data )+":"+"steven").getBytes() , null );
	}
}
