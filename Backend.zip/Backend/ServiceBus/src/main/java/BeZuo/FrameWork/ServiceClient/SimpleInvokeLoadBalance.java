package BeZuo.FrameWork.ServiceClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import BeZuo.Common.ServiceEndPoint;

public class SimpleInvokeLoadBalance implements IInvokeLoadBalance
{
	//�򵥼�¼��ÿ��������ô���
	private Map<String,Integer> invokeCount;
	public SimpleInvokeLoadBalance()
	{
		invokeCount	= new HashMap<String,Integer>();
	}
	synchronized public ServiceEndPoint GetServiceChannel(String serviceName,String funcName, List<ServiceEndPoint> availableEndPoint) 
	{
		// TODO Auto-generated method stub
		if( null != availableEndPoint && availableEndPoint.size() != 0 )
		{
			Integer count	= invokeCount.get( serviceName );
			if( null == count )
			{
				count	= new Integer(0);
				invokeCount.put( serviceName , count );
			}
			count++;
			int index	= count % availableEndPoint.size();
			return availableEndPoint.get( index );
		}
		return null;
	}

}
