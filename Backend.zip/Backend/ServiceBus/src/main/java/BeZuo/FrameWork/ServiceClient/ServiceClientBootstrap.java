package BeZuo.FrameWork.ServiceClient;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Map;
import java.util.Map.Entry;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.util.AttributeKey;

public class ServiceClientBootstrap extends Bootstrap
{
	//��������Ƚ�Σ�գ������汾��Ҫ�����Ż�,��ΪĿǰֻ��һ���̵߳���connect��������ʱ�������
	private AttributeKey<String> ipAttri;
	private AttributeKey<Integer> portAttri;
	public ServiceClientBootstrap()
	{
		ipAttri		= AttributeKey.newInstance("EndPointIP");
		portAttri	= AttributeKey.newInstance("EndPointPort");
	}
	private void SetChannelContext( String ip , int port )
	{
		try
		{
			attr( ipAttri , ip);
			attr( portAttri, new Integer(port) );
		}
		catch(Exception e)
		{
			
		}
	}
	@Override
	public ChannelFuture connect(String inetHost, int inetPort) 
	{
		//System.out.println( "ServiceClientBootstrap connect");
		SetChannelContext( inetHost , inetPort );
		ChannelFuture channelFuture	= super.connect( inetHost , inetPort  );
        return channelFuture;
    }
}
