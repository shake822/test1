package BeZuo.FrameWork.ServiceClient;

import BeZuo.Common.CommonFuture;
import BeZuo.Common.ServiceInvokeProtocolObj;
import BeZuo.Common.ServiceResponseStatus;
import BeZuo.FrameWork.ServiceClient.ServiceInvokeSession.RequsetIdentify;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandler;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelPipeline;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpResponseStatus;


public class ServiceInvokeHandlerInBound  extends ChannelInboundHandlerAdapter
{
	private ServiceChannnelManager serviceChannnelManager;
	private ServiceInvokeSession serviceInvokeSession;
	//ĳ��ȷ����FD��channelRead����һֱ����ȷ����ͬһ���߳������У�����ʹ��ͬһ��buffer������Ҫ�����߳����⡣
	//private byte[]	redBuffer;
	//pipeline���󲻻�仯��Ϊ�˲���Ҫÿ�����������newһ���ö���
	private RequsetIdentify identifier;
	
	public ServiceInvokeHandlerInBound()
	{
		//��Ҫ��������֧�֣������Ż�
		//redBuffer	= new byte[ 16 * 1024 ];
		
		identifier	= null;
	}
	public void SetServiceChannnelManager( ServiceChannnelManager manager )
	{
		serviceChannnelManager	= manager;
	}
	public void SetServiceInvokeSession( ServiceInvokeSession session )
	{
		serviceInvokeSession	= session;
	}
	@Override
	//���÷�������Ӧ����
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception 
	{				
		if( msg instanceof FullHttpResponse )
		{
			FullHttpResponse resp	= (FullHttpResponse) msg;
			int readableBytes		= resp.content().readableBytes();	
			byte[] redBuffer		= new byte[ readableBytes ];
			resp.content().getBytes( 0 , redBuffer );
			
			String seqNumStr	= resp.headers().get( "SeqNum" );
			//System.out.println( "seqNumStr:"+seqNumStr);
			int seqNum	= 0;
			if( null != seqNumStr )
			{
				seqNum	= Integer.valueOf( seqNumStr );
			}
			
			if( null == identifier )
			{
				identifier	= new RequsetIdentify( ctx.pipeline() , seqNum );
			}
			identifier.SetSeqNum( seqNum );
			
			CommonFuture<byte[]> result	= (CommonFuture<byte[]>) serviceInvokeSession.GetRequestFutureAndRemove( identifier );
			
			HttpResponseStatus resCode				= resp.getStatus();				
			ServiceResponseStatus responseStatus	= ServiceResponseStatus.ValueOf( resCode.code() );
			
			if( responseStatus.equals( ServiceResponseStatus.OK ) )
			{
				result.SetResult( redBuffer  );				
			}	
			else if( responseStatus.equals( ServiceResponseStatus.PROMPT_ERROR ) || responseStatus.equals( ServiceResponseStatus.INTERNAL_ERROR ) )
			{
				String exceptionMsg	= new String( redBuffer ); 
				result.SetServiceResponseStatus( responseStatus , exceptionMsg, new Exception( exceptionMsg ) );
			}
			else 
			{
				result.SetServiceResponseStatus( responseStatus , responseStatus.GetReasonPhrase() , new Exception( responseStatus.GetReasonPhrase()  ) );
			}
		}
		ctx.fireChannelRead(msg);
	}
	@Override
	public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
		//System.out.println( "client channelRegistered" );
		serviceChannnelManager.ChannelRegisted( ctx.pipeline() );
		
		ctx.fireChannelRegistered();
	}

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		//System.out.println( "client channelActive" );
		serviceChannnelManager.ConnectionBuildOK(ctx.pipeline());
	   ctx.fireChannelActive();
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		//System.out.println( "client channelInactive" );
	 	serviceChannnelManager.ConnectionInvalidate(ctx.pipeline());
	    ctx.fireChannelInactive();
	}
	//һ�˷�syn�����������û�м�����ֱ�ӷ�RST��λ�źŹ��������������ӵ�һ��ֱ�ӵ��ø÷�����
	 @Override
	public void channelUnregistered(ChannelHandlerContext ctx) throws Exception
	{
		// System.out.println( "client channelUnregistered" );
		 serviceChannnelManager.ChannelUnRegisted( ctx.pipeline() );
		 ctx.fireChannelUnregistered();
	}
}
