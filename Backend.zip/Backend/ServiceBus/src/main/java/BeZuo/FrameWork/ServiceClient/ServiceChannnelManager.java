package BeZuo.FrameWork.ServiceClient;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import BeZuo.Common.IServiceRegister;
import BeZuo.Common.ServiceEndPoint;
import BeZuo.Common.ServiceRegisteEntry;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPipeline;
import io.netty.util.AttributeKey;

public class ServiceChannnelManager 
{
	private Bootstrap bootstrap;
	//����ע����
	private IServiceRegister serviceRegister;
	private IInvokeLoadBalance loadBalance;
	//���з���ˣ�ͨ���������ֽ���ӳ��
	//private Map<String ,ServiceEndPoint > serviceMap;
	//���з���ˣ�ͨ��ͨ������ӳ��
	private Map< ServiceEndPoint , SeriveState > serviceMapWithChannel;
	
	public ServiceChannnelManager()
	{
		bootstrap		= null;
		serviceRegister	= null;
		loadBalance		= null;
		serviceMapWithChannel	= new HashMap< ServiceEndPoint , SeriveState >();
	}
	synchronized private SeriveState GetSeriveState( ServiceEndPoint serviceEndPoint )
	{	
		SeriveState state	= serviceMapWithChannel.get( serviceEndPoint );
		if( null == state )
		{
			state	= new SeriveState( serviceEndPoint );
			serviceMapWithChannel.put( serviceEndPoint , state );
		}
		return state;
	}
	class SeriveState
	{
		//����˶�Ӧ��ip�Ͷ˿�
		ServiceEndPoint serviceEndPoint;
		//�Ƿ��Ѿ����ù�connect����
		boolean isConnecting;
		//�Ƿ��Ѿ�����ע�ᣬ��׼����������
		boolean isRegisted;
		//�Ƿ���һ��������������
		boolean isConnected;
		//ͨ��netty����������������
		ChannelPipeline connection;
		
		public SeriveState( ServiceEndPoint endPoint )
		{
			serviceEndPoint	= endPoint;
			isConnected		= false;
			isRegisted		= false;
			isConnecting	= false;
			connection		= null;
		}	
		public String toString()
		{
			StringBuffer buf	= new StringBuffer("IsConnected:");
			buf.append( isConnected ).append(",isRegisted:").append( isRegisted ).append(",isConneting:");
			buf.append( isConnecting );
			buf.append("conne:").append( null == connection );
			return buf.toString();
		}
	}	
	//����һ���̣߳�ά����������������˵�����
	class MaintainServiceThread implements Runnable
	{
		public void run() 
		{
			while( true )
			{
				//System.out.println( "--- CheckChannel State ") ;
				Set<ServiceEndPoint> serviceLocation	=  serviceRegister.GetAllServiceLocation();
				for( ServiceEndPoint endPoint : serviceLocation )
				{
					SeriveState state		= GetSeriveState( endPoint );
					if( !( state.isConnected || state.isRegisted || state.isConnecting ) )
					{
						//System.out.println( state.toString());
						//System.out.println( "CONNECT + "+ endPoint.GetIP() + "+" + endPoint.GetPort() );
						bootstrap.connect( endPoint.GetIP(), endPoint.GetPort());
						state.isConnecting	= true;
					}	
				}
				try {
					Thread.sleep( 2 * 1000 );
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void StartServiceWithDaemon()
	{
		Thread thread	= new Thread( new MaintainServiceThread() );
		thread.start();
		//thread.setDaemon( true );
	}	
	synchronized public void ChannelUnRegisted( ChannelPipeline conContext )
	{
		String endPointIP			= (String) conContext.channel().attr( AttributeKey.valueOf("EndPointIP") ).get();
		Number endPointPort			= (Number) conContext.channel().attr( AttributeKey.valueOf("EndPointPort") ).get();
		//System.out.println( "EndPointIP:"+ endPointIP );
		//System.out.println( "endPointPort:"+ endPointPort );
		ServiceEndPoint endPoint	= new ServiceEndPoint( endPointIP ,endPointPort.intValue() );
		
		SeriveState state			= serviceMapWithChannel.get( endPoint );
		if( null != state )
		{
			state.isRegisted	= false;	
			state.isConnected	= false;
			state.isConnecting	= false;
			state.connection	= null;
		}
		
	}
	synchronized public void ChannelRegisted( ChannelPipeline conContext)
	{
		String endPointIP			= (String) conContext.channel().attr( AttributeKey.valueOf("EndPointIP") ).get();
		Number endPointPort			= (Number) conContext.channel().attr( AttributeKey.valueOf("EndPointPort") ).get();
		//System.out.println( "EndPointIP:"+ endPointIP );
		//System.out.println( "endPointPort:"+ endPointPort );
		ServiceEndPoint endPoint	= new ServiceEndPoint( endPointIP ,endPointPort.intValue() );

		SeriveState state			= serviceMapWithChannel.get( endPoint );
		if( null != state )
		{
			state.isRegisted	= true;	
			state.isConnected	= false;
			state.isConnecting	= false;
			state.connection	= conContext;
		}
		
	}
	
	synchronized public void ConnectionBuildOK( ChannelPipeline conContext)
	{
		//serviceMap.put( , value)
		String endPointIP			= (String) conContext.channel().attr( AttributeKey.valueOf("EndPointIP") ).get();
		Number endPointPort			= (Number) conContext.channel().attr( AttributeKey.valueOf("EndPointPort") ).get();
		ServiceEndPoint endPoint	= new ServiceEndPoint( endPointIP ,endPointPort.intValue() );
		SeriveState state			= serviceMapWithChannel.get( endPoint );
		if( null != state )
		{
			state.isRegisted	= true;	
			state.isConnected	= true;
			state.isConnecting	= false;
		}
	}
	synchronized public void ConnectionInvalidate( ChannelPipeline conContext)
	{
		//System.out.println( "ConnectionInvalidate" );
		String endPointIP			= (String) conContext.channel().attr( AttributeKey.valueOf("EndPointIP") ).get();
		Number endPointPort			= (Number) conContext.channel().attr( AttributeKey.valueOf("EndPointPort") ).get();
		ServiceEndPoint endPoint	= new ServiceEndPoint( endPointIP ,endPointPort.intValue() );
		SeriveState state			= serviceMapWithChannel.get( endPoint );
		if( null != state )
		{
			//System.out.println( "ConnectionInvalidate SET" );
			state.isConnected		= false;
			state.isRegisted		= false;
			state.isConnecting		= false;
			state.connection		= null;
		}
	}
	synchronized ChannelPipeline GetServiceChannel( String serviceName, String funcName )
	{
		List<ServiceEndPoint> endPointList	= serviceRegister.GetServiceLocation( serviceName, funcName );
		ArrayList<ServiceEndPoint> avilableChannel	= new ArrayList<ServiceEndPoint>();
		
		if( null != endPointList )
		{
			for( ServiceEndPoint endPoint : endPointList )
			{
				SeriveState state	= GetSeriveState( endPoint );
				if( state.isConnected )
				{
					avilableChannel.add( endPoint );
				}
			}
			ServiceEndPoint choice	= loadBalance.GetServiceChannel( serviceName, funcName, avilableChannel );
			if( null != choice )
			{
				return GetSeriveState(choice).connection;
			}
		}
		return null;
	}
		
	public void setServiceRegister( IServiceRegister serviceRegister )
	{
		this.serviceRegister	= serviceRegister;
	}
	public void setBootstrap( Bootstrap bootstrap )
	{
		this.bootstrap	= bootstrap;
	}
	public void setLoadBalance( IInvokeLoadBalance loadBalance )
	{
		this.loadBalance	= loadBalance;
	}
	
	
}
