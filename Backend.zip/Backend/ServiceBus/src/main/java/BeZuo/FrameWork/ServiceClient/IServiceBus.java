package BeZuo.FrameWork.ServiceClient;

import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceInvokeFuture;

public interface IServiceBus 
{
	public <T> ServiceInvokeFuture<T> InvokeService( String ServiceName , String Func , ServiceContextInfo contextInfo, Object param );
}
