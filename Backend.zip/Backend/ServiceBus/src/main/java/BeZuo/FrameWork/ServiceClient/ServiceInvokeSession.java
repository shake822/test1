package BeZuo.FrameWork.ServiceClient;

import java.util.LinkedHashMap;
import java.util.Map;

import BeZuo.Common.CommonFuture;
import BeZuo.Common.ServiceEndPoint;
import io.netty.channel.ChannelPipeline;


public class ServiceInvokeSession 
{
	Map<RequsetIdentify, RequestResult> request;
	int nextSeq;
	
	public ServiceInvokeSession()
	{
		request	= new LinkedHashMap< RequsetIdentify, RequestResult >();
		nextSeq	= 0;
	}
	public int GetNextSeq()
	{
		return nextSeq++;
	}
	public synchronized int  EraseOldRequest()
	{
		//���ҵ����������Ѿ����ڡ�
		int count;
		
		for( Map.Entry<RequsetIdentify, RequestResult> entry : request.entrySet() )
		{
			if( entry.getValue().GetEclapeTime() > 3000 )
			{
				request.remove( entry.getKey() );
			}
			else
			{
				break;
			}
		}
		
		return 0;
	}
	public synchronized void  PutRequest( RequsetIdentify identify , CommonFuture<?> future )
	{
		request.put( identify , new RequestResult(future) );
	}
	public synchronized CommonFuture<?> GetRequestFutureAndRemove( RequsetIdentify req)
	{
		RequestResult result	= request.remove( req );
		if( null != result )
		{
			return result.GetRequestFuture();
		}
		return null;
	}
	
	class RequestResult
	{
		CommonFuture<?> future;
		long timeStamp;
		RequestResult( CommonFuture<?> future )
		{
			this.future	= future;
			timeStamp	= System.currentTimeMillis();
		}
		long GetEclapeTime()
		{
			return System.currentTimeMillis() - timeStamp;
		}
		CommonFuture<?> GetRequestFuture()
		{
			return future;
		}
	}
	//ͨ��channel �� seqnum ��ʶһ������
	public static class RequsetIdentify
	{
		ChannelPipeline pipeline;
		int seqNum;
		public RequsetIdentify( ChannelPipeline pipeline , int seqNum)
		{
			this.pipeline	= pipeline;
			this.seqNum		= seqNum;
		}
		public void SetSeqNum( int seqNum )
		{
			this.seqNum	= seqNum;
		}
		@Override
	    public boolean equals(Object o) {
	        if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;

	        RequsetIdentify other = (RequsetIdentify) o;

	        if(  other.pipeline == this.pipeline  &&  this.seqNum == (other.seqNum) )
	        {
	        	return true;
	        }

	        return false;
	    }

	    @Override
	    public int hashCode() 
	    {
	        return pipeline.hashCode() + seqNum ;
	    }
	}
}
