package BeZuo.FrameWork.ServiceClient;

import java.util.List;

import BeZuo.Common.ServiceEndPoint;

public interface IInvokeLoadBalance 
{
	ServiceEndPoint GetServiceChannel( String serviceName, String funcName , List<ServiceEndPoint> availableEndPoint );
}
