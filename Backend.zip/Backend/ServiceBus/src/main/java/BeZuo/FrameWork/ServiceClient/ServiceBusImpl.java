package BeZuo.FrameWork.ServiceClient;

import java.net.InetSocketAddress;

import BeZuo.Common.CommonFuture;
import BeZuo.Common.LocalServiceContext;
import BeZuo.Common.ServiceAgent;
import BeZuo.Common.ServiceContextInfo;
import BeZuo.Common.ServiceInvokeFuture;
import BeZuo.Common.ServiceInvokeProtocolObj;
import BeZuo.Common.ServiceInvokeResult;
import BeZuo.Common.ServiceRegister;
import BeZuo.Common.ServiceResponseStatus;
import BeZuo.FrameWork.ServiceClient.ServiceInvokeSession.RequsetIdentify;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.HttpClientCodec;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.util.AttributeKey;

public class ServiceBusImpl implements IServiceBus
{
	//private SOAFrameWork frameWork;
	private ServiceChannnelManager serviceChannnelManager;
	private ServiceInvokeSession serviceInvokeSession;
	private Bootstrap clientBootstrap;
	private EventLoopGroup eventLoopGroup;
	private LocalServiceContext localServiceContext;
	private ServiceAgent serviceAgent;
	public <T> ServiceInvokeFuture<T> InvokeService(String serviceName, String funcName,ServiceContextInfo contextInfo, Object param) {
		// TODO Auto-generated method stub
		
		CommonFuture<T> future		= new CommonFuture<T>();		
		ChannelPipeline pipeline	= serviceChannnelManager.GetServiceChannel( serviceName , funcName );
		if( null != pipeline )
		{
			String endPointIP			= (String) pipeline.channel().attr( AttributeKey.valueOf("EndPointIP") ).get();
			Number endPointPort			= (Number) pipeline.channel().attr( AttributeKey.valueOf("EndPointPort") ).get();
			
			//������õ�ҵ������ڱ����ϣ�ֱ�ӵ��÷���	
			if(  this.localServiceContext.GetLocalServiceEndPoint().GetIP().equals( endPointIP ) && this.localServiceContext.GetLocalServiceEndPoint().GetPort() == endPointPort.intValue() )
			{
				ServiceInvokeResult result	= (ServiceInvokeResult)serviceAgent.InvokeService(serviceName, funcName, contextInfo, param);
				if( null != result )
				{
					future.SetResult( (T) result.GetResultData() );
				}
			}
			else
			{						
				int reqNum	= serviceInvokeSession.GetNextSeq() ;
				ServiceInvokeProtocolObj serviceInvokeProtocolObj	= new ServiceInvokeProtocolObj( serviceName , funcName ,contextInfo, param ,  reqNum );
				pipeline.write( serviceInvokeProtocolObj );
				serviceInvokeSession.PutRequest( new ServiceInvokeSession.RequsetIdentify( pipeline , reqNum ), future );
			}
		}
		else
		{
			//future.SetExcuteExceptioned( "Service is down" , new Exception() );
			future.SetServiceResponseStatus( ServiceResponseStatus.INTERNAL_ERROR , serviceName + " Service is down"  , new Exception( serviceName+" Service is down") );
			future.NotifyBlock();
		}
		return future;
		
	}
	public ServiceBusImpl( EventLoopGroup workGroup , LocalServiceContext localServiceContext ,ServiceAgent serviceAgent )
	{
		//this.frameWork			= frameWork;
		eventLoopGroup				= workGroup;
		this.localServiceContext	= localServiceContext;
		this.serviceAgent			= serviceAgent;
		clientBootstrap				= null;
		serviceChannnelManager		= null;
		serviceInvokeSession		= null;
	}
	
	public Bootstrap GetBootstrap()
	{
		return clientBootstrap;
	}
	
	public void initWithServiceChannnelManager( final ServiceChannnelManager serviceChannnelManager )
	{
		clientBootstrap			= new ServiceClientBootstrap();
		
		this.serviceChannnelManager	= serviceChannnelManager;
		serviceChannnelManager.setBootstrap( clientBootstrap );
		
		serviceInvokeSession	= new ServiceInvokeSession();
	
		clientBootstrap.group(eventLoopGroup)
          .channel(NioSocketChannel.class)
          .option(ChannelOption.TCP_NODELAY, true)
          .handler(new ChannelInitializer<SocketChannel>() {
              @Override
              public void initChannel(SocketChannel ch) throws Exception {
                  ChannelPipeline p = ch.pipeline();
                  //p.addLast(new LoggingHandler(LogLevel.INFO));
                  p.addLast("http",new HttpClientCodec() );
             	  p.addLast("httpAgg",new HttpObjectAggregator( 8192 ));
             	  ServiceInvokeHandlerInBound invokeHandlerInBound	= new ServiceInvokeHandlerInBound();
             	  invokeHandlerInBound.SetServiceChannnelManager( serviceChannnelManager );
             	  invokeHandlerInBound.SetServiceInvokeSession( serviceInvokeSession );
                  p.addLast( "invokeHandlerInBound1",invokeHandlerInBound );
                  p.addLast( "ServiceInvokeHandlerOutBound1", new ServiceInvokeHandlerOutBound() );
              }
          });		
	}
	 public int BeginService() 
	 {
		serviceChannnelManager.StartServiceWithDaemon();
		return 0;
	 }
	 /*
	@Override
	public SOAFrameWork GetSOAFrameWork() {
		// TODO Auto-generated method stub
		return frameWork;
	}
	*/
}
