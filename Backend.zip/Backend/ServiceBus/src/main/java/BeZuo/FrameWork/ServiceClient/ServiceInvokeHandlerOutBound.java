package BeZuo.FrameWork.ServiceClient;

import java.util.Map;

import BeZuo.Common.ServiceInvokeProtocolObj;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.handler.codec.http.DefaultFullHttpRequest;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpVersion;

public class ServiceInvokeHandlerOutBound extends ChannelOutboundHandlerAdapter
{
	@Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
		System.out.println( "respnse write");
		
		ServiceInvokeProtocolObj invokeObj	= (ServiceInvokeProtocolObj)msg;
		StringBuffer buf	= new StringBuffer("/");
		buf.append( invokeObj.GetServiceName() ).append( "/" ).append( invokeObj.GetFuncName() );
		
		DefaultFullHttpRequest request = new DefaultFullHttpRequest( HttpVersion.HTTP_1_1, HttpMethod.POST ,buf.toString() );
		Object param	= invokeObj.GetParam() ;
		int paramLen	= 0;
		if( null != param )
		{		
			byte[] paramBytes	= (byte[]) param;
			paramLen = paramBytes.length;
			request.content().writeBytes( paramBytes );
		}
		Map<String,String> contextInfo	= invokeObj.GetServiceContextInfo().GetInvokeServiceContextInfo();
		for( Map.Entry< String , String > entry : contextInfo.entrySet() )
		{
			if( ! ( entry.getKey().equals( "SeqNum" ) ||  entry.getKey().equals("Content-Length") ) )
			{
				request.headers().add( entry.getKey() , entry.getValue() );
			}
		}
		request.headers().add( "SeqNum" , String.valueOf( invokeObj.GetSeqNum() ) );
		request.headers().add( "Content-Length"  , String.valueOf( paramLen ) );
		ctx.write( request, promise);
		ctx.flush();
    }
}
