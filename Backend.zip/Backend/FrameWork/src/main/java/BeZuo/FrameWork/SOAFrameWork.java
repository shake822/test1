package BeZuo.FrameWork;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import BeZuo.Common.ServiceHolder;
import BeZuo.Common.ServiceRegister;
import BeZuo.Common.SpringServiceHolder;
import BeZuo.FrameWork.ServiceClient.ServiceBusImpl;
import BeZuo.FrameWork.ServiceClient.ServiceChannnelManager;
import BeZuo.FrameWork.ServiceContainer.ServiceContainer;

public class SOAFrameWork 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("FrameWork.xml");		 
		ServiceBusImpl serviceBus	= (ServiceBusImpl) context.getBean("ServiceBus");
		if( null == serviceBus )
		{
			//System.out.println( "Spring config item : ServiceBusImpl error");
		}
		ServiceChannnelManager channnelManager	= (ServiceChannnelManager)context.getBean("ServiceChannnelManager");
		if( null == channnelManager )
		{
			//System.out.println( "Spring config item : ServiceChannnelManager error");
		}
		
		serviceBus.initWithServiceChannnelManager( channnelManager );	
		ServiceContainer serviceContainer		= (ServiceContainer)context.getBean("ServiceContainer");
		SpringServiceHolder serviceHolder		= (SpringServiceHolder)context.getBean("ServiceHolder");
		serviceHolder.setApplicationContext( context );
		
		ServiceRegister serviceRegister		= (ServiceRegister)context.getBean("ServiceRegister");
		
		serviceContainer.BeginService();
		
		serviceBus.BeginService();
		
		serviceContainer.WaitForClose();

	}
}
