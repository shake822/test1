package BeZuo.Common;

public interface IConfigurableObject 
{
	void UpdateConfig( ConfItem conf );
}
