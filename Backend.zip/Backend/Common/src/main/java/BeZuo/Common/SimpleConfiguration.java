package BeZuo.Common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SimpleConfiguration implements IConfiguration
{
	Map<String, String> configStrings;
	Map<String, Map<String,String>> configMaps;
	Map<String, List<String>> configLists;
	public void init()
	{
		configStrings	= new HashMap<String,String> ();
		configMaps		= new HashMap<String,Map<String,String>> ();
		configLists		= new HashMap<String, List<String>> ();
		//����beanӳ������
		Map<String,String> beans	= new HashMap<String,String>();
		beans.put( "UserInfoService|*" , "UserInfoService" );
		beans.put( "MainPageService|*" , "MainPageService" );
		beans.put( "ImageService|*" , "ImageService" );
		configMaps.put( "BeansConfigure", beans);
		
		Map<String,String> serviceLocation	= new HashMap<String,String>();
		serviceLocation.put( "UserInfoService|*" , "192.168.31.111:8888" );
		serviceLocation.put( "ImageService|*" , "192.168.31.111:8888" );
		configMaps.put( "ServiceConfigure" , serviceLocation );
		
		configStrings.put( "ImageService\\CacheItemSize" , "1024" );
		configStrings.put( "ImageService\\BaseLocation" , "d:\\uploadImage\\" );
		
		List<String> fdfsTrackerServerList	= new ArrayList<String>();
		fdfsTrackerServerList.add( "192.168.31.2:22122" );
		configLists.put( "FdfsConf\\TrackerServerList" , fdfsTrackerServerList );
		
		configStrings.put( "FdfsConf\\Charset" , "utf-8" );
		
		
	}
	public String GetStringConf(String confItem) 
	{
		// TODO Auto-generated method stub
		return configStrings.get( confItem );
	}

	public Map<String, String> GetMapConf(String confItem) {
		// TODO Auto-generated method stub
		return configMaps.get( confItem );
	}

	public List<String> GetListConf(String confItem) {
		// TODO Auto-generated method stub
		return configLists.get( confItem );
	}

}
