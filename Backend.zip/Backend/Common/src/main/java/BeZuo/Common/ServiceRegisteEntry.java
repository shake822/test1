package BeZuo.Common;

import java.util.Iterator;
 
public class ServiceRegisteEntry
{
	private ServiceEndPoint endPoint;
	private String serviceName;
	private String funcName;
	public ServiceRegisteEntry( ServiceEndPoint endPoint , String serviceName )
	{
		this.endPoint		= endPoint;
		this.serviceName	= serviceName;
		this.funcName		= "*";
	}
	public ServiceRegisteEntry( ServiceEndPoint endPoint , String serviceName , String funcName )
	{
		this.endPoint		= endPoint;
		this.serviceName	= serviceName;
		this.funcName		= funcName;
	}
	public String getServiceName()
	{
		return serviceName;
	}
	public String GetFuncName()
	{
		return funcName;
	}
	public ServiceEndPoint GetEndPoint()
	{
		return endPoint;
	}
}
