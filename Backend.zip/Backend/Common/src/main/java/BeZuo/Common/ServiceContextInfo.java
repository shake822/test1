package BeZuo.Common;

import java.util.Map;
import java.util.TreeMap;

public  class ServiceContextInfo
{
	Map<String,String> infos;
	private Map<String,String> getContextInfoForAssign()
	{
		if( null == infos )
		{
			infos	= new TreeMap<String,String>();
		}
		return infos;
	}
	public ServiceContextInfo()
	{
		infos	= null;
	}
	public void AddContextInfo( String key , String value )
	{
		if( null == infos )
		{
			infos	= new TreeMap<String,String>();
		}
		infos.put( key , value );
	}
	public Map<String,String> GetInvokeServiceContextInfo()
	{
		return infos;
	}
	public void AssignTo( ServiceContextInfo another )
	{
		for( Map.Entry<String, String> entry : infos.entrySet() )
		{
			another.AddContextInfo( entry.getValue() , entry.getKey() );
		}
	}
}
