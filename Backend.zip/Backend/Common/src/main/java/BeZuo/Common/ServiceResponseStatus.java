package BeZuo.Common;

import io.netty.handler.codec.http.HttpResponseStatus;

public class ServiceResponseStatus {

	private final int code;
	private final String reasonPhrase;
	
	public static final ServiceResponseStatus INTERNAL_ERROR 	= new ServiceResponseStatus(601, "internal error" );
	public static final ServiceResponseStatus PROMPT_ERROR 		= new ServiceResponseStatus(602, "Prompt error" );
	public static final ServiceResponseStatus OK 				= new ServiceResponseStatus( 200 , "ok" );
	public static final ServiceResponseStatus UNKNOWN 			= new ServiceResponseStatus( -1 , "unknown" );
	public ServiceResponseStatus( int code , String reasonPhrase )
	{
		this.code			= code;
		this.reasonPhrase	= reasonPhrase;
	}
	public boolean equals(Object o) 
	{
	   if (!(o instanceof ServiceResponseStatus )) 
	   {
		   return false;
	   }
	   return code() == ((ServiceResponseStatus) o).code();
	}
	public int code() 
	{
		// TODO Auto-generated method stub
		return code;
	}
	public String GetReasonPhrase()
	{
		return reasonPhrase;
	}
	public static ServiceResponseStatus ValueOf( int code )
	{
		switch( code )
		{
		case 200 :
			return OK;
		case 601:
			return INTERNAL_ERROR;
		case 602:
			return INTERNAL_ERROR;
		default:
			return 	UNKNOWN;
		}
	}
	 
}