package BeZuo.Common;

public class ServiceInvokeResult 
{
	ServiceResponseStatus responseStatus;
	private ServiceContextInfo resultContextInfo;
	private Object resultData;
	 
	public Object GetResultData()
	{
		return resultData;
	}
	public ServiceContextInfo GetResultContext()
	{
		return resultContextInfo;
	}
	public ServiceResponseStatus GetResponseStatus()
	{
		return responseStatus;
	}
	public ServiceInvokeResult(  ServiceResponseStatus responseStatus , Object resultData , ServiceContextInfo resultContextInfo )
	{
		this.resultData			= resultData;
		this.resultContextInfo	= resultContextInfo;
		this.responseStatus		= responseStatus;
	}
}
