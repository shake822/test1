package BeZuo.Common;

public interface ServiceInvokePromise<T> 
{
	void SetResult( T result );
	void CancelRequest();
	void SetServiceResponseStatus( ServiceResponseStatus status , String errMsg , Throwable exception );
	void SetReqTimeouted();
}
