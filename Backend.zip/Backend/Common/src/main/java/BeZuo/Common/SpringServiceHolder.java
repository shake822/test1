package BeZuo.Common;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;


public class SpringServiceHolder extends ServiceHolder
{
	class ServiceBeanRegisteEntry
	{
		String beanName;
		String serviceName;
		String funcName;
		public ServiceBeanRegisteEntry( String beanName , String serviceName )
		{
			this.beanName		= beanName;
			this.serviceName	= serviceName;
			this.funcName		= "*";
		}
		public ServiceBeanRegisteEntry( String beanName , String serviceName , String funcName )
		{
			this.beanName		= beanName;
			this.serviceName	= serviceName;
			this.funcName		= funcName;
		}		
	}
	
	interface IServiceBeanRegister
	{
		String GetServiceBeanName( String serviceName , String funcName ) ;
		public List<ServiceBeanRegisteEntry> LoadServiceRegisteEntryList();
	}
	
	class ServiceBeanRegister implements IServiceBeanRegister
	{
		private  final static String  STAR	= "*" ;
		private Map<String ,String > serviceMap;
		//��¼����ֻͨ���������Ϳ��Զ�λ��ӳ��
		private Set<String> serviceNameEnough;
		IConfiguration conf;
		
		public ServiceBeanRegister( IConfiguration conf )
		{
			serviceNameEnough	= new HashSet<String>();
			serviceMap			= new HashMap< String ,String >();
			this.conf			= conf;
		}

		public List<ServiceBeanRegisteEntry> LoadServiceRegisteEntryList() {
			// TODO Auto-generated method stub
			Map<String,String> beansConf				= conf.GetMapConf( "BeansConfigure" );
			List<ServiceBeanRegisteEntry> resultList	= new ArrayList<ServiceBeanRegisteEntry>();
			for( Map.Entry< String , String> entry : beansConf.entrySet() )
			{
				String serviceNameAndFunc	= entry.getKey();
				String[] array	= serviceNameAndFunc.split("[|]");
				int len		= array.length ;
				if( 2 == len )
				{
					ServiceBeanRegisteEntry registerEntry	= new ServiceBeanRegisteEntry( entry.getValue() , array[0] , array[1] );
					resultList.add( registerEntry );
				}
				else if( 1 == len )
				{
					ServiceBeanRegisteEntry registerEntry	= new ServiceBeanRegisteEntry( entry.getValue() , array[0]  );
					resultList.add( registerEntry );
				}
			}
			return resultList;
		}
		public void init()
		{
			List<ServiceBeanRegisteEntry>	list = LoadServiceRegisteEntryList();
			for( ServiceBeanRegisteEntry entry : list )
			{
				String addServiceFunc		= null;
				if( entry.funcName.equals( STAR ) )
				{
					serviceNameEnough.add( entry.serviceName );
					addServiceFunc	= entry.serviceName;				
				}
				else
				{
					addServiceFunc	= entry.serviceName + entry.funcName;
				}
				serviceMap.put( addServiceFunc , entry.beanName );
			}		
			
		}
		
		public String GetServiceBeanName( String serviceName , String funcName ) 
		{
			String result	= serviceMap.get( serviceName + funcName );
			if( null != result )
			{
				return result;
			}
			else
			{
				result = serviceMap.get( serviceName );
			}
			return result;		
		}
		
	}
	
	
	private ApplicationContext context;
	private IServiceBeanRegister serviceBeanRegister;
	Map<String , Object> beans;
	Map<String , Method> methods;
	
	public SpringServiceHolder( IConfiguration conf )
	{
		beans					= new HashMap<String , Object> ();
		methods					= new HashMap<String , Method >();
		serviceBeanRegister		= new ServiceBeanRegister( conf );
		this.context			= null;
	}
	public void init()
	{
		( (ServiceBeanRegister)serviceBeanRegister).init();
	}
	public void setApplicationContext( ApplicationContext context  )
	{
		this.context			= context;
	}
	@Override
	public Object GetServiceObject(String serviceName, String funcName) {
		// TODO Auto-generated method stub
		String 	beanName = serviceBeanRegister.GetServiceBeanName( serviceName, funcName );
		Object result	= null;
		if( null != beanName )
		{
			result	= beans.get( beanName );
			if( null == result )
			{
				try
				{
					result	= context.getBean( beanName );
				}
				catch( Exception e )
				{
					result	= null;
				}
				if( null != result )
					beans.put( beanName , result );
			}
		}		
		return result;
	}

	@Override
	public Method GetServiceMethod(String serviceName, String funcName) 
	{
		// TODO Auto-generated method stub
		StringBuffer buffer	= new StringBuffer( serviceName ).append(funcName);
		String key		= buffer.toString();
		Method method	= null;
		method	= 	methods.get( key );
		if( null == method )
		{
			Object obj	= GetServiceObject( serviceName , funcName );
			if( null != obj )
			{
				method	= getServiceMethod( funcName ,  obj.getClass() , byte[].class );
				if( null != method )
				{
					methods.put( key, method );
				}
			}
		}
		return method;
	}
	private Method getServiceMethod(  String funcName , Class<? extends Object> objClass , Class<byte[]> paramType )
	{
		Method method	= null;
		try 
		{
			method	=  objClass.getMethod( funcName , paramType , ServiceContextInfo.class );
		} 
		catch (NoSuchMethodException e ) 
		{
			// TODO Auto-generated catch block
			method 	= null;
		} catch ( SecurityException e )
		{
			method 	= null;
		}		
		return method;
	}
}
