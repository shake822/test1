package BeZuo.Common;

import java.util.List;
import java.util.Map;

public interface IConfiguration {
	/*
	 * 
	 * */
	String GetStringConf(String confItem );
	Map<String,String> GetMapConf( String confItem );
	List<String> GetListConf( String confItem );
}
