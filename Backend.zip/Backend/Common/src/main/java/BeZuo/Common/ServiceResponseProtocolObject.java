package BeZuo.Common;

import io.netty.handler.codec.http.HttpResponseStatus;

public class ServiceResponseProtocolObject
{
	int seqNum;
	//HttpResponseStatus httpRetCode;
	ServiceInvokeResult result;
	public ServiceResponseProtocolObject(  ServiceInvokeResult result, int seqNum )
	{
		//this.httpRetCode	= httpRetCode;
		this.seqNum			= seqNum;
		this.result			= result;
	}
	public int GetSeqNum()
	{
		return seqNum;
	}
	/*
	public HttpResponseStatus GetHttpRetCode()
	{
		return httpRetCode;
	}
	*/
	public ServiceInvokeResult GetResult()
	{
		return result;
	}
}
