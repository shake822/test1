package BeZuo.Common;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class CommonFuture<T> implements ServiceInvokeFuture<T> , ServiceInvokePromise<T> 
{
	CountDownLatch countLatch;
	boolean isDone;
	boolean isCancel;
	boolean isException;
	boolean isTimeouted;
	String errMsg;
	ServiceResponseStatus status;
	Throwable executionException;
	T result;
	public CommonFuture()
	{
		countLatch	= new CountDownLatch(1);
		isDone		= false;
		isCancel	= false;
		isException	= false;
		isTimeouted = false;
		result		= null;
		errMsg		= null;
		executionException	= null;
	}
	public void SetResult(T result) {
		// TODO Auto-generated method stub
		this.result	= result;
		isDone		= true;
		countLatch.countDown();
	}
	public void CancelRequest() {
		// TODO Auto-generated method stub
		result		= null;
		isCancel	= true;
		countLatch.countDown();
	}
	public void SetReqTimeouted() {
		// TODO Auto-generated method stub
		result		= null;
		isTimeouted	= true;
		countLatch.countDown();
	}
	public void SetServiceResponseStatus( ServiceResponseStatus status , String errMsg , Throwable exception )
	{
		this.status			= status;
		executionException	= exception;
		this.errMsg			= errMsg;
		isException			= true;
		result				= null;
	}
	public void NotifyBlock()
	{
		countLatch.countDown();
	}
	public String GetErrMsg()
	{
		return errMsg;
	}
	public ServiceResponseStatus GetServiceResponseStatus()
	{
		return status;
	}
	public boolean isCancelled() {
		// TODO Auto-generated method stub
		return isCancel;
	}
	public boolean isDone() {
		// TODO Auto-generated method stub
		return isDone;
	}
	public boolean isException()
	{
		return isException;
	}
	
	public T get()
	{
		// TODO Auto-generated method stub
		if( isDone )
		{
			return this.result;
		}
		if( isCancel || isException || isTimeouted )
		{			
			return null;
		}
		else
		{
			while(true)
			{
				try 
				{
					countLatch.await( );
				} 
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					continue;
				}		
				if( isDone )
				{
					return this.result;
				}
				if( isCancel || isException || isTimeouted )
				{			
					return null;
				}
				
			}
		}
	}
	public T get( long timeout ) 
	{
		// TODO Auto-generated method stub
		if( isDone )
		{
			return this.result;
		}
		if( isCancel || isException || isTimeouted )
		{			
			return null;
		}
		while( true)
		{
			try 
			{
				countLatch.await( timeout , TimeUnit.MILLISECONDS );
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				continue;
			}
			
			if( isDone )
			{
				return this.result;
			}
			if( ! ( isCancel || isException ) )
			{		
				isTimeouted	= true;
			}
			return null;				
		}		
	}
	public boolean isTimeout() {
		// TODO Auto-generated method stub
		return isTimeouted;
	}
}
