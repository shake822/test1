package BeZuo.Common;

public class ServiceEndPoint 
{
	private	String ip;
	private	int port;
	public ServiceEndPoint( String ip, int port)
	{
		this.ip		= ip;
		this.port	= port;
	}
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceEndPoint other = (ServiceEndPoint) o;

        if(  other.ip.equals( this.ip ) && ( this.port	== other.port) )
        {
        	return true;
        }

        return false;
    }

    @Override
    public int hashCode() 
    {
        return ip.hashCode() + port ;
    }
    public String GetIP()
    {
    	return ip;
    }
    public int GetPort()
    {
    	return port;
    }
}
