package BeZuo.Common;

import java.util.ArrayList;
import java.util.List;


public abstract class ConfItem
{	
	List<IConfigurableObject> configurableObjects;
	public ConfItem()
	{
		configurableObjects	= new ArrayList<IConfigurableObject>(1);
		ConfigManager.GetInstance().AddConfItem( this );
	}
	public void AddConfigurableObject( IConfigurableObject obj )
	{
		configurableObjects.add( obj );
	}
	public void NotifyChange( )
	{
		for( IConfigurableObject confObj : configurableObjects )
		{
			confObj.UpdateConfig( this );
		}
	}
	public abstract boolean equals( ConfItem conf );
	public abstract void InitWithConfigure( IConfiguration conf );
	/*������Ϣ�Ѿ�����,�������*/
	public boolean UpdateIfConfChange( IConfiguration conf )
	{
		try {
			ConfItem tmp	= this.getClass().newInstance();
			if(	this.equals( tmp ) )
			{
				return false;
			}
			else
			{
				this.InitWithConfigure( conf );
				NotifyChange();
				return true;
			}
			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
}
