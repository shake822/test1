package BeZuo.Common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import BeZuo.Common.SpringServiceHolder.ServiceBeanRegisteEntry;

public class ServiceRegister implements IServiceRegister
{
	//List<ServiceRegisteEntry> lists;
	//���з���ˣ�ͨ���������ֺͷ�������ӳ��
	private Map<String ,List<ServiceEndPoint> > serviceMap;
	//��¼����ֻͨ���������Ϳ��Զ�λ��ӳ��
	private Set<String> serviceNameEnough;
	final static String STAR	= "*";
	private IConfiguration conf;
	public ServiceRegister( IConfiguration conf )
	{
		//lists				= new ArrayList<ServiceRegisteEntry>();
		serviceNameEnough	= new HashSet<String>();
		serviceMap			= new HashMap< String ,List<ServiceEndPoint> >();
		this.conf			= conf;
	}
	
	public void init()
	{
		List<ServiceRegisteEntry>	list = LoadServiceRegisteEntryList();
		for( ServiceRegisteEntry entry : list )
		{
			//System.out.println( "init LoadServiceRegisteEntryList ");
			String addServiceFunc		= null;
			ServiceEndPoint addEndPoint	= entry.GetEndPoint();
			if( entry.GetFuncName().equals( STAR ) )
			{
				serviceNameEnough.add( entry.getServiceName() );
				addServiceFunc	= entry.getServiceName();				
			}
			else
			{
				addServiceFunc	= entry.getServiceName() + entry.GetFuncName();
			}
			List<ServiceEndPoint> endPointList	= serviceMap.get( addServiceFunc );
			if(  null == endPointList )
			{
				endPointList	= new ArrayList<ServiceEndPoint>( );					
				serviceMap.put( addServiceFunc , endPointList );
			}				
			endPointList.add( addEndPoint );
		}		
		
	}
	
	public List<ServiceEndPoint> GetServiceLocation( String serviceName , String funcName ) 
	{
		List<ServiceEndPoint> resultEndPointList	= serviceMap.get( serviceName + funcName );
		if( null != resultEndPointList )
		{
			return resultEndPointList;
		}
		else
		{
			resultEndPointList = serviceMap.get( serviceName );
			if( null != resultEndPointList )
			{
				return resultEndPointList;
			}
		}
		return null;		
	}
	
	public Set<ServiceEndPoint> GetAllServiceLocation( )
	{
		Set<ServiceEndPoint> serviceLocation	= new HashSet<ServiceEndPoint>();
		for( Map.Entry< String ,List<ServiceEndPoint> > entry : serviceMap.entrySet() )
		{
			for( ServiceEndPoint endPoint : entry.getValue() )
			{
				serviceLocation.add( endPoint );
			}
		}
		return serviceLocation;		
	}
	
	public List<ServiceRegisteEntry> LoadServiceRegisteEntryList()
	{
		ArrayList<ServiceRegisteEntry> resultList	= new ArrayList<ServiceRegisteEntry>();
		Map<String,String>	mapConfs	= conf.GetMapConf( "ServiceConfigure" );
		for( Map.Entry< String , String> entry : mapConfs.entrySet() )
		{
			String serviceNameAndFunc	= entry.getKey();
			String endPointStr			= entry.getValue();
			String[] endPointArray	= endPointStr.split(":");
			if(  2 != endPointArray.length )
			{
				continue;
			}
			String ip	= endPointArray[0];
			int port	= 0;
			try
			{
				port	= Integer.valueOf( endPointArray[1] );
			}
			catch( NumberFormatException e)
			{
				continue;
			}
			
			String[] array	= serviceNameAndFunc.split("[|]");
			int len		= array.length ;
			if( 2 == len )
			{
				ServiceRegisteEntry registerEntry	= new ServiceRegisteEntry( new ServiceEndPoint( ip , port), array[0] , array[1] );
				resultList.add( registerEntry );
			}
			else if( 1 == len )
			{
				ServiceRegisteEntry registerEntry	= new ServiceRegisteEntry(  new ServiceEndPoint( ip , port) , array[0] );
				resultList.add( registerEntry );
			}
		}		
		return resultList;
	}
	
}
