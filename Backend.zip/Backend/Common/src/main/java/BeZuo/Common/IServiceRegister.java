package BeZuo.Common;

import io.netty.channel.ChannelPipeline;

import java.util.List;
import java.util.Set;

public interface IServiceRegister 
{
	public List<ServiceEndPoint> GetServiceLocation( String serviceName , String funcName ) ;
	public Set<ServiceEndPoint> GetAllServiceLocation();
	public List<ServiceRegisteEntry> LoadServiceRegisteEntryList();
}
