package BeZuo.Common;

import java.util.Map;
import java.util.TreeMap;

public class ServiceInvokeProtocolObj 
{	
	private String serviceName;
	private String funcName;
	private Object param;
	private ServiceContextInfo contextInfo;
	private int seqNum;
	public ServiceInvokeProtocolObj( String serviceName , String funcName , ServiceContextInfo contextInfo, Object param ,int seqNum )
	{
		this.serviceName	= serviceName;
		this.funcName		= funcName;
		this.param			= param;
		this.contextInfo	= contextInfo;
		this.seqNum			= seqNum;
	}
	public void SetSeqNum( int seqNum )
	{
		this.seqNum	= seqNum;
	}
	public int GetSeqNum()
	{
		return seqNum;
	}
	public void SetServiceName( String serviceName )
	{
		this.serviceName	= serviceName;
	}
	public String GetServiceName()
	{
		return serviceName;
	}
	
	public void SetFuncName( String funcName )
	{
		this.funcName	= funcName;
	}
	public String GetFuncName()
	{
		return funcName;
	}
	public ServiceContextInfo GetServiceContextInfo()
	{
		return contextInfo;
	}
	
	public void SetParam( Object param )
	{
		this.param	= param;
	}
	public Object GetParam()
	{
		return param;
	}
}
