package BeZuo.Common;

import java.lang.reflect.Method;

public abstract class ServiceHolder
{
	public abstract Object GetServiceObject( String serviceName , String funcName );
	public abstract Method GetServiceMethod( String serviceName , String funcName );
}