package BeZuo.Common;

import java.util.ArrayList;
import java.util.List;

public class ConfigManager 
{
	static ConfigManager _instance	= new ConfigManager();
	private ConfigManager()
	{
		confItems		= new ArrayList<ConfItem>();
	};
	static ConfigManager GetInstance()
	{
		return _instance;
	}
	private	List<ConfItem> confItems;
	public void AddConfItem( ConfItem item ) 
	{
		confItems.add( item );
	}
}
