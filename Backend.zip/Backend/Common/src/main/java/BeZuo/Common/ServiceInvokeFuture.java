package BeZuo.Common;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public interface ServiceInvokeFuture<T>
{
	 boolean isCancelled();
	 boolean isDone();
	 boolean isTimeout();
	 boolean isException();
	 ServiceResponseStatus GetServiceResponseStatus();
	 String GetErrMsg();
	 T get();
	 T get(long timeout );
}

