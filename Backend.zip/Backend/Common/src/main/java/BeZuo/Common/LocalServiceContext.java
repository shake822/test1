package BeZuo.Common;

public class LocalServiceContext 
{
	private ServiceEndPoint serviceEndPoint;
	public LocalServiceContext( String ip , int port )
	{
		serviceEndPoint	= new ServiceEndPoint( ip , port );
	}
	public ServiceEndPoint GetLocalServiceEndPoint()
	{
		return serviceEndPoint;
	}
}
