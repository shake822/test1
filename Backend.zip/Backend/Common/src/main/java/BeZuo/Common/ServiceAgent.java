package BeZuo.Common;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import BeZuo.Common.ServiceContextInfo;

public class ServiceAgent 
{
	private ServiceHolder serviceHolder;
	public ServiceAgent( ServiceHolder serviceHolder )
	{
		this.serviceHolder	= serviceHolder;
	}
	/*
	public void setServiceHolder( ServiceHolder serviceHolder)
	{
		this.serviceHolder	= serviceHolder;
	}
	*/
	public Object InvokeService( String serviceName , String funcName  , ServiceContextInfo contextInfo , Object param )
	{
		//System.out.println("InvokeService");
		if( null != serviceHolder )
		{
			Object obj	= serviceHolder.GetServiceObject(serviceName, funcName);
			if( null != obj )
			{
				Method method	= serviceHolder.GetServiceMethod(serviceName, funcName);
				if( null != method )
				{
					Object result	= null;
					try {
						result 	= method.invoke( obj , param , contextInfo );
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						//result	= null;
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						//result	= null;
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						//result	= null;
						e.printStackTrace();
					}
					return result;
				}
			}
		}
		return null;
	}
}
